/*
Copyright 2019-2020 NXP
All rights reserved.
SPDX-License-Identifier: BSD-3-Clause
*/
#ifndef GENFSK_SW_VERSION_H
#define GENFSK_SW_VERSION_H

#define XCVR_TAG "release_fwk_ksdk_2.6_kw37a_5.7.7_qpatch_RC1"
#define XCVR_SHA1 "16746bbbe3cee1a32459298c952c0c8ebeb9ecb0 (Thu Aug 6 09:29:55 2020 +0200)"
#define GENFSK_TAG "release_genfsk_ksdk_2.6_kw37a_3.0.4"
#define GENFSK_SHA1 "ff70d3aad4464585fecfb508aae8938be8cb94fb (Wed Jul 15 19:06:12 2020 +0200)"
#define GENFSK_DATE "Wed Jul 15 19:06:12 2020 +0200"

#endif
